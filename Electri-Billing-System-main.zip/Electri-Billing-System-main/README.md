# Electri-Billing-System

The proposed system automates the conventional process of paying electricity bill by visiting the Electricity Board which is tiresome and time consuming.
It is also designed to automate the electricity bill calculation and payment for user convenience. 
The system is developed with Java swings as the base programming language which can be used to develop websites, web applications and web services. 
